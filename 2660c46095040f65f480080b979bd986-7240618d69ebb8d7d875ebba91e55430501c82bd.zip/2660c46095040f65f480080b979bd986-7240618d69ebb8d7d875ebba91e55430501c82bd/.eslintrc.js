module.exports = {
    'extends': 'lighthouselabs',
};
